#!/bin/bash
# Copyright (C) 2026 xuanfeng0316
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

exec 3<>/dev/tcp/127.0.0.1/25566

send_recv() {
    echo "$1" >&3
    head -n1 <&3
}

trap 'exit 0' INT

while true; do
    ENTITIES=$(send_recv '{"id":1,"method":"get_nearby_entities","params":{"radius":5}}')
    IDS=$(echo "$ENTITIES" | grep -o '{"id":[0-9]*,"type":"minecraft:[a-z_]*"' | grep -v 'minecraft:item' | grep -o '"id":[0-9]*' | grep -o '[0-9]*')

    for EID in $IDS; do
        send_recv "{\"id\":2,\"method\":\"attack_entity\",\"params\":{\"entityId\":$EID}}" > /dev/null
    done
done
