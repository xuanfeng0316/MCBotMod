#!/bin/bash
# Copyright (C) 2026 xuanfeng0316
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

read -p "x: " X
read -p "y: " Y
read -p "z: " Z
read -p "face (回车自动): " FACE
read -p "timeout ms (回车=无限): " TO

exec 3<>/dev/tcp/127.0.0.1/25566

PARAMS="\"x\":$X,\"y\":$Y,\"z\":$Z"
[ -n "$FACE" ] && PARAMS="$PARAMS,\"face\":\"$FACE\""
[ -n "$TO" ] && PARAMS="$PARAMS,\"timeout\":$TO"

echo "{\"id\":1,\"method\":\"break_block\",\"params\":{$PARAMS}}" >&3

echo "Ctrl+C 退出"
while IFS= read -r line <&3; do
    echo "$line"
done
