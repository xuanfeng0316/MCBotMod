#!/bin/bash
# Copyright (C) 2026 xuanfeng0316
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

read -p "host: " HOST
read -p "port (回车=25565): " PORT
[ -z "$PORT" ] && PORT=25565

exec 3<>/dev/tcp/127.0.0.1/25566
echo "{\"id\":1,\"method\":\"connect_server\",\"params\":{\"host\":\"$HOST\",\"port\":$PORT}}" >&3

echo "Ctrl+C 退出"
while IFS= read -r line <&3; do echo "$line"; done
