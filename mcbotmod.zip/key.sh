#!/bin/bash
# Copyright (C) 2026 xuanfeng0316
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

read -p "key: " KEY
read -p "action (回车=click): " ACT

exec 3<>/dev/tcp/127.0.0.1/25566
if [ -z "$ACT" ]; then
  echo "{\"id\":1,\"method\":\"key\",\"params\":{\"key\":\"$KEY\"}}" >&3
else
  echo "{\"id\":1,\"method\":\"key\",\"params\":{\"key\":\"$KEY\",\"action\":\"$ACT\"}}" >&3
fi
head -n1 <&3
